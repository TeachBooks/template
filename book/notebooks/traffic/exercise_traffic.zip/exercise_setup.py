import numpy as np
import pandas as pd
from scipy.stats import burr12
from scipy import stats
import matplotlib.pyplot as plt
from ipywidgets import interact
import warnings
import ipywidgets as widgets


class Trajectory():
    
    
    def __init__(self):
        self.alpha = 0.15
        self.beta = 4.0
        self.t_0 = 28.52
        self.C = 5600.0
        self.rCf = 0.2
        self.q = 5500.0
        self.t_cutoff = self.travel_time_method_1()
        self.observations_filename = 'traveltime.csv'
        
        [self.travel_time_df,
         self.travel_time,
         self.flow_rate,
         self.t_accident,
         self.t_delay] = self.process_observations()
        
        self.burr_parameters = self.fit_burr()
        
        self.plot_q_min = 0
        self.plot_q_max = 6000
        self.plot_q_increment = 100
        self.plot_q_values = np.linspace(0, self.plot_q_max,
                                            self.plot_q_increment)
        
        self.plot_t_min = 20
        self.plot_t_max = 60
        self.plot_t_increment = 100
        self.plot_t_values = np.linspace(self.plot_t_min,
                                         self.plot_t_max,
                                         self.plot_t_increment)
        
    def print_parameters(self):
        """Print current values used in Method 1 and 2."""
        
        print(f'Current parameter values are:'
              f'\n    alpha = {self.alpha:.2f}'
              f'\n     beta = {self.beta:.0f}'
              f'\n      t_0 = {self.t_0:.1f}'
              f'\n        C = {self.C:.0f}'
              f'\n      rCf = {self.rCf:.1f}'
              f'\n        q = {self.q:.0f}')
        
    def process_observations(self):
        """Create dataframe with observations.
        
        Steps:
          - Import file defined by string attribute observations_filename.
          - Extract all columns with observations.
          - Set up and return new dataframe:
              - travel_time_df
          - Set up and return new arrays:
              - travel_time
              - flow_rate
              - t_accident
          - dataframe and arrays are added as attributes in init
        """
        travel_time_raw = pd.read_csv(self.observations_filename)
        travel_time = np.array(travel_time_raw.iloc[:,1:-6])
        travel_time = travel_time.reshape(
            travel_time.shape[0]*travel_time.shape[1])
        travel_time_df = pd.DataFrame(
            travel_time, columns=['Travel Time'])
        flow_rate = ((((travel_time/self.t_0) - 1)
                                /self.alpha)**(1/self.beta))*self.C
        t_accident = []
        t_delay = []
        for i in range(len(travel_time)):
            if travel_time[i]>self.t_cutoff:
                t_delay.append(travel_time[i] - self.t_cutoff)
                t_accident.append(
                    2*self.q*t_delay[i]/(self.q - self.rCf*self.C))
                
            else:
                t_delay.append(0.0)
                t_accident.append(0.0)
        
        return [travel_time_df,
                travel_time,
                flow_rate,
                np.array(t_accident),
                np.array(t_delay)]

    def estimate_t_delay(self,
                          t_accident=None,
                          q=None,
                          C=None,
                          rCf=None,):
        """Compute accident delay from accident duration.
        
        Delay is the extra time along the trajectory experienced by a
        single vehicle due to an accident, estimated as follows:
            t = t_cufoff + t_delay
        """
        if t_accident is None:
            assume_t_accident = 10
            t_accident = assume_t_accident
            print(f'A single accident duration of {assume_t_accident} min '
                  f'is assumed by default. Include argument t_accident=? '
                  f'to override.')
        if q is None:
            q = self.q
        if rCf is None:
            rCf = self.rCf
        if C is None:
            C = self.C
        return t_accident*(q - rCf*C)/(2*q)

    def travel_time_method_1(self,
                             q=None,
                             alpha=None,
                             beta=None,
                             t_0=None,
                             C=None):
        """Compute travel time with Method 1.
        
        Keyword arguments: q, alpha, beta, t_0, C.
        Returns: travel time as float or array, depending on input.
        """
        if q is None:
            q = self.q
        if alpha is None:
            alpha = self.alpha
        if beta is None:
            beta = self.beta
        if t_0 is None:
            t_0 = self.t_0
        if C is None:
            C = self.C
        return t_0*(1 + alpha*(q/C)**beta)
    
    def fit_burr(self, travel_time=None):
        """Fits Burr distribution using a dataframe.
        
        Uses fit(data) method of scipy stats continuous random variable
        class, which returns list of parameters: [c, k, loc, scale].
        Parameters can be printed using print_parameters_burr(parameters).
        """
        if travel_time is None:
            travel_time = self.travel_time_df
        if isinstance(travel_time,np.ndarray):
            travel_time = pd.DataFrame(travel_time, columns=['Travel Time'])
        dist = getattr(stats, 'burr12')
        with np.errstate(divide='ignore', invalid='ignore', over='ignore'):
            parameters = dist.fit(travel_time['Travel Time'])
        return parameters
    
    def print_parameters_burr(self, parameters=None):
        """Print parameters of Burr distribution, no interventions."""
        if parameters is None:
            parameters = self.burr_parameters
        print(f'Parameters are:'
              f'\n    c  = {parameters[0]:.3f}'
              f'\n    k  = {parameters[1]:.3e}'
              f'\n   loc = {parameters[2]:.2f}'
              f'\n scale = {parameters[3]:.2f}')
    
    def burr_ppf(self, ppf, parameters=None):
        """Evaluates ppf method of burr dist using attributes or input."""
        if parameters is None:
            parameters = self.burr_parameters
        return stats.burr12.ppf(ppf,
                                parameters[0],
                                parameters[1],
                                parameters[2],
                                parameters[3])
    
    def plot_method_1(self):
        """Plot travel time with Method 1 (BPR)."""
        plt.plot(self.plot_q_values,
                 self.travel_time_method_1(self.plot_q_values),
                 color="red", label="Method 1 (BPR)")
        plt.ylim([self.plot_t_min, self.plot_t_max])
        plt.xlabel('Traffic Flow Rate [vehicles per hour]')
        plt.ylabel('Travel Time [min]')
        plt.legend()

    def plot_method_1_sliders(self, t_0, C):
        """Compute travel time with Method 1 sliders"""
        plt.plot(self.plot_q_values,
                 self.travel_time_method_1(self.plot_q_values,
                                           t_0=t_0,
                                           C=C),
                 color="red", label="Method 1 (BPR)")
        plt.ylim([self.plot_t_min, self.plot_t_max])
        plt.xlabel('Traffic Flow Rate [vehicles per hour]')
        plt.ylabel('Travel Time [min]')
        plt.legend()
    
    def travel_time_method_2(self,
                             t_accident=None,
                             q=None,
                             C=None,
                             rCf=None,
                             t_cutoff=None):
        """Compute travel time with Method 2 (delays).
        
        Keyword arguments: t_accident, q, C, rCf, t_cutoff.
        Returns: travel time as float or array, depending on input.
        """
        """
        Important note: q is only used for computation of accident
        duration here, it is not used to recompute the cutoff time,
        as that is an assumption made for the entire trajectory under
        all conditions. Change t_cutoff directly if you wish to change
        this assumption.
        """
        if t_accident is None:
            assume_t_accident = 10
            t_accident = assume_t_accident
            print(f'A single accident duration of {assume_t_accident} min '
                  f'is assumed by default. Include argument t_accident=? '
                  f'to override.')
        if q is None:
            q = self.q
        if C is None:
            C = self.C
        if rCf is None:
            rCf = self.rCf
        if t_cutoff is None:
            t_cutoff = self.t_cutoff
        return t_cutoff + self.estimate_t_delay(t_accident, q, C, rCf)
    
    def plot_method_2(self):
        """Plot travel time with Method 2."""
        plt.plot(self.plot_q_values,
                 self.travel_time_method_2(self.plot_q_values),
                 color="red", label="Method 2 (delays)")
        plt.ylim([self.plot_t_min, self.plot_t_max])
        plt.xlabel('Traffic Flow Rate [vehicles per hour]')
        plt.ylabel('Travel Time [min]')
        plt.legend()

    def plot_method_2_sliders(self, t_accident, C, rCf, t_cutoff):
        """Compute travel time with Method 2 sliders"""
        plt.plot(self.plot_q_values,
                 self.travel_time_method_2(t_accident=t_accident,
                                           q=self.plot_q_values,
                                           C=C,
                                           rCf=rCf,
                                           t_cutoff=t_cutoff),
                 color="red", label="Method 2 (delays)")
        plt.ylim([self.plot_t_min, self.plot_t_max])
        plt.xlabel('Traffic Flow Rate [vehicles per hour]')
        plt.ylabel('Travel Time [min]')
        plt.legend()
        
    def plot_distribution_method_1_variables(self, t_0, flowfactor, C, baseline):
        """Compute distribution with Method 1 sliders."""
        if baseline==True:
            c, k, loc, scale = self.fit_burr(
                self.travel_time_method_1(q=self.flow_rate))
            plt.plot(self.plot_t_values,
                 burr12.pdf(self.plot_t_values, c, k, loc, scale),
                 color="black", label="Baseline")
        c, k, loc, scale = self.fit_burr(
            self.travel_time_method_1(
                q=flowfactor*self.flow_rate, t_0=t_0, C=C))
        with np.errstate(divide='ignore', invalid='ignore', over='ignore'):
            plt.plot(self.plot_t_values,
                 burr12.pdf(self.plot_t_values, c, k, loc, scale),
                 color="red", label="Method 1 (BPR)")
        plt.xlim([self.plot_t_min, self.plot_t_max])
        plt.ylim([0,0.2])
        plt.xlabel('Travel time [min]')
        plt.ylabel('Probability density, $f_t(t)\:$ [$-$]')
        plt.legend()
        
    def plot_distribution_method_1(self,
                                   extra_lane,
                                   max_speed,
                                   alt_route,
                                   modal_shift_trucks,
                                   modal_shift_cars,
                                   baseline,
                                   plot_type):
        """Compute distribution with Method 1 sliders."""
        if baseline==True:
            c, k, loc, scale = self.fit_burr(
                self.travel_time_method_1(q=self.flow_rate))
            if plot_type == 'pdf':
                plt.plot(self.plot_t_values,
                         burr12.pdf(self.plot_t_values, c, k, loc, scale),
                         color="black", label="Baseline")
            elif plot_type == 'cdf':
                plt.plot(self.plot_t_values,
                         burr12.cdf(self.plot_t_values, c, k, loc, scale),
                         color="black", label="Baseline")
            elif plot_type == 'exc':
                plt.plot(self.plot_t_values,
                         1 - burr12.cdf(self.plot_t_values, c, k, loc, scale),
                         color="black", label="Baseline")
        c, k, loc, scale = self.fit_burr(
            self.intervention_method_1(q_distribution=True,
                                       extra_lane=extra_lane,
                                       max_speed=max_speed,
                                       alt_route=alt_route,
                                       modal_shift_trucks=modal_shift_trucks,
                                       modal_shift_cars=modal_shift_cars))
        with np.errstate(divide='ignore', invalid='ignore', over='ignore'):
            if plot_type == 'pdf':
                plt.plot(self.plot_t_values,
                         burr12.pdf(self.plot_t_values,c, k, loc, scale),
                         color="red", label="Method 2 (Delays)")
                plt.ylim([0,0.2])
            elif plot_type == 'cdf':
                plt.plot(self.plot_t_values,
                         burr12.cdf(self.plot_t_values,c, k, loc, scale),
                         color="red", label="Method 2 (Delays)")
                plt.ylim([0,1])
            elif plot_type == 'exc':
                plt.plot(self.plot_t_values,
                         1 - burr12.cdf(self.plot_t_values,c, k, loc, scale),
                         color="red", label="Method 2 (Delays)")
                plt.yscale('log')
                plt.ylim([1e-3,1])
        plt.xlim([self.plot_t_min, self.plot_t_max])
        plt.xlabel('Travel time [min]')
        plt.ylabel('Probability density, $f_t(t)\:$ [$-$]')
        plt.legend()
        
    def intervention_method_1(self,
                              q_distribution=False,
                              extra_lane=None,
                              max_speed=None,
                              alt_route=None,
                              modal_shift_trucks=None,
                              modal_shift_cars=None):
        """Compute travel time with interventions with Method 1.
        
        Use keyword arguments to 'modify' the trajectory by
        applying an intervention.
        
        Keyword arguments:
              extra_lane
              max_speed
              alt_route
              modal_shift_trucks
              modal_shift_cars
              
        q_distribution used to evaluate with float or array.
        
        Returns: float or array of travel time(s).
        """
        if q_distribution == False:
            q = self.q
        else:
            q = self.flow_rate
        if extra_lane == None:
            C_i = self.C
        elif extra_lane == 1:
            C_i = self.C*1.2
        elif extra_lane == 2:
            C_i = self.C*1.35
        else:
            raise ValueError("extra_lane be equal to 1 or 2, "
                             "or must be left empty")
        if max_speed == None:
            t_0i = self.t_0
        elif max_speed > 1.3*130:
            raise ValueError("You can only increase max_speed "
                             "up to 30% (169 km/hr)")
        elif max_speed <= 0:
            raise ValueError("You cannot have a max_speed "
                             "below 0 km/hr")
        else:
            t_0i = self.t_0/(max_speed/130)
        if alt_route == None:
            q_i = q
        elif alt_route == 1:
            q_i = q*0.75
        elif alt_route == 2:
            q_i = q*0.6
        else:
            raise ValueError("alt_route must be equal to 1 or 2, "
                             "or must be left empty")
        if modal_shift_trucks == None:
            q_i = q_i
        elif modal_shift_trucks > 20:
            raise ValueError("You can only decrease the flow of "
                             "trucks up to 20% (modal_shift_trucks)")
        else:
            q_i = q_i*(9/10.9 + 1.9*(1-modal_shift_trucks/100)/10.9)
        if modal_shift_cars == None:
            q_i = q_i
        elif modal_shift_cars > 20:
            raise ValueError("You can only decrease the flow of cars "
                             "up to 20% (modal_shift_cars)")
        else:
            q_i = q_i*(9*(1 - modal_shift_cars/100)/10.9 + 1.9/10.9)
        return self.travel_time_method_1(q=q_i, t_0=t_0i, C=C_i)
        
    def burr_ppf_with_int_1(self,
                            ppf,
                            extra_lane=None,
                            max_speed=None,
                            alt_route=None,
                            modal_shift_trucks=None,
                            modal_shift_cars=None):
        """Compute travel time as F^-1(ppf) with interventions, Method 1."""
        q_distribution = True
        c, k, loc, scale = self.fit_burr(
            self.intervention_method_1(q_distribution,
                                       extra_lane, max_speed, 
                                       alt_route, modal_shift_trucks,
                                       modal_shift_cars))
        return stats.burr12.ppf(ppf, c, k, loc, scale)
    
    def plot_distribution_method_2_variables(self,
                                   C, rCf, t_cutoff,baseline):
                                   # old inputs:
                                   # timefactor, t_0, C, rC, q):
        """Compute distribution with Method 2 sliders"""
        # old setup:
        # t_cutoff = t_0*(1 + self.alpha*(q/C)**self.beta)
        # t = []
        # for i in range(len(self.travel_time)):
        #     if self.travel_time[i]>t_cutoff:
        #         t.append(
        #             t_cutoff + timefactor*(q - rC)
        #             *self.t_accident[i]/(2*q))
        #     else:
        #         t.append(self.travel_time[i])
        # t = np.array(t)
        if baseline==True:
            c, k, loc, scale = self.fit_burr(
                self.travel_time_method_1(q=self.flow_rate))
            plt.plot(self.plot_t_values,
                 burr12.pdf(self.plot_t_values, c, k, loc, scale),
                 color="black", label="Baseline")
        c, k, loc, scale = self.fit_burr(
                self.travel_time_method_2(t_accident=self.t_accident,
                                           q=self.q,
                                           C=C,
                                           rCf=rCf,
                                           t_cutoff=t_cutoff))
        with np.errstate(divide='ignore', invalid='ignore', over='ignore'):
            plt.plot(self.plot_t_values,
                 burr12.pdf(self.plot_t_values,c, k, loc, scale),
                 color="red", label="Method 2 (Delays)")
        plt.xlim([self.plot_t_min, self.plot_t_max])
        plt.ylim([0,0.2])
        plt.xlabel('Travel Time [minutes]')
        plt.ylabel('Probability')
        plt.legend()
        
    def plot_distribution_method_2(self,
                                   extra_lane,
                                   hard_shoulder,
                                   max_speed,
                                   alt_route,
                                   incident_management,
                                   accident_risk_reduction,
                                   modal_shift_trucks,
                                   modal_shift_cars,
                                   baseline,
                                   plot_type):
                                   # old inputs:
                                   # timefactor, t_0, C, rC, q):
        """Compute distribution with Method 2 sliders"""
        if baseline==True:
            c, k, loc, scale = self.fit_burr(
                self.travel_time_method_1(q=self.flow_rate))
            if plot_type == 'pdf':
                plt.plot(self.plot_t_values,
                         burr12.pdf(self.plot_t_values, c, k, loc, scale),
                         color="black", label="Baseline")
            elif plot_type == 'cdf':
                plt.plot(self.plot_t_values,
                         burr12.cdf(self.plot_t_values, c, k, loc, scale),
                         color="black", label="Baseline")
            elif plot_type == 'exc':
                plt.plot(self.plot_t_values,
                         1 - burr12.cdf(self.plot_t_values, c, k, loc, scale),
                         color="black", label="Baseline")
        c, k, loc, scale = self.fit_burr(
           self.intervention_method_2(q_distribution=True,
                                      extra_lane=extra_lane,
                                      hard_shoulder=hard_shoulder,
                                      max_speed=max_speed,
                                      alt_route=alt_route,
                                      incident_management=incident_management,
                                      accident_risk_reduction=accident_risk_reduction,
                                      modal_shift_trucks=modal_shift_trucks,
                                      modal_shift_cars=modal_shift_cars))
        with np.errstate(divide='ignore', invalid='ignore', over='ignore'):
            if plot_type == 'pdf':
                plt.plot(self.plot_t_values,
                         burr12.pdf(self.plot_t_values,c, k, loc, scale),
                         color="red", label="Method 2 (Delays)")
                plt.ylim([0,0.2])
            elif plot_type == 'cdf':
                plt.plot(self.plot_t_values,
                         burr12.cdf(self.plot_t_values,c, k, loc, scale),
                         color="red", label="Method 2 (Delays)")
                plt.ylim([0,1])
            elif plot_type == 'exc':
                plt.plot(self.plot_t_values,
                         1 - burr12.cdf(self.plot_t_values,c, k, loc, scale),
                         color="red", label="Method 2 (Delays)")
                plt.yscale('log')
                plt.ylim([1e-3,1])
        plt.xlim([self.plot_t_min, self.plot_t_max])
        plt.xlabel('Travel Time [minutes]')
        plt.ylabel('Probability')
        plt.legend()
            
    def intervention_method_2(self,
                              q_distribution=False,
                              extra_lane=None,
                              hard_shoulder=None,
                              max_speed=None,
                              alt_route=None,
                              incident_management=None,
                              accident_risk_reduction=None,
                              modal_shift_trucks=None,
                              modal_shift_cars=None):
        """Compute travel time with interventions with Method 2
        
        Use keyword arguments to 'modify' the trajectory by
        applying an intervention.
        
        Keyword arguments:
              extra_lane
              hard_shoulder
              max_speed
              alt_route
              incident_management
              accident_risk_reduction
              modal_shift_trucks
              modal_shift_cars
              
        q_distribution used to evaluate with float or array.
        
        Returns: float or array of travel time(s).
        """
        if q_distribution == False:
            q = self.q
        else:
            q = self.flow_rate
        if extra_lane == None or extra_lane == 0:
            C_i = self.C
        elif extra_lane == 1:
            C_i = self.C*1.2
        elif extra_lane == 2:
            C_i = self.C*1.35
        else:
            raise ValueError("extra_lane must be equal to 1 or 2, "
                             "or must be left empty")
        if hard_shoulder == None or hard_shoulder == False:
            rCf_i = self.rCf
        elif hard_shoulder == True:
            rCf_i = self.rCf*2
        else:
            raise ValueError("hard_shoulder must be True or False")
        if max_speed == None:
            t_0i = self.t_0
        elif max_speed > 170:
            raise ValueError("You can only increase max_speed "
                             "up to ~30% (170 km/hr)")
        elif max_speed < 0:
            raise ValueError("max_speed must be greater than 0 km/hr")
        else:
            t_0i = self.t_0/(max_speed/130.0)
        if alt_route == None or alt_route == 0:
            q_a = self.q
        elif alt_route == 1:
            q_a = self.q*0.75
        elif alt_route == 2:
            q_a = self.q*0.6
        else:
            raise ValueError("alt_route must be equal to 1 or 2, "
                             "or must be left empty")
        if incident_management == None:
            t_accident_n = self.t_accident.copy()
        elif incident_management > 100:
            raise ValueError("You can only decrease the duration "
                             "of the accident up to 100%")
        elif incident_management < 0:
            raise ValueError("You cannot increase the duration of "
                             "an accident.")
        elif incident_management < 1:
            raise ValueError("You must decrease the duration of "
                             "accidents by at least 1%")
        else:
            t_accident_n = (1 - incident_management/100.0)*self.t_accident.copy()
        if accident_risk_reduction == None:
            t_accident_i = t_accident_n.copy()
        elif accident_risk_reduction > 100:
            raise ValueError("You can only decrease the number of "
                             "accidents up to 100%")
        elif accident_risk_reduction < 1:
            raise ValueError("You must decrease the number of "
                             "accidents by at least 1%")
        else:
            t_accident_i = t_accident_n.copy()
            sorted_indices = np.argsort(t_accident_i)[::-1]
            num_values = int(len(t_accident_i)*accident_risk_reduction/100)
            for i in range(num_values):
                t_accident_i[sorted_indices[i]] = 0
        if modal_shift_trucks == None:
            q_m = q_a
        elif modal_shift_trucks > 20:
            raise ValueError("You can only decrease the flow of "
                             "trucks up to 20%")
        else:
            q_m = q_a*(9/10.9 + 1.9*(1-modal_shift_trucks/100)/10.9)
        if modal_shift_cars == None:
            q_i = q_m
        elif modal_shift_cars > 20:
            raise ValueError("You can only decrease the flow of "
                             "cars up to 20%")
        else:
            q_i = q_m*(9*(1 - modal_shift_cars/100)/10.9 + 1.9/10.9)
        t_cutoff = t_0i*(1 + self.alpha*(q_i/C_i)**self.beta)
        t = []
        for i in range(len(self.travel_time)):
            if self.travel_time[i]>t_cutoff:
                t.append(t_cutoff + (q_i - rCf_i*C_i)*t_accident_i[i]/(2*q_i))
            else:
                t.append(self.travel_time[i])
        return np.array(t)
        
    def burr_ppf_with_int_2(self,
                          ppf,
                          extra_lane=None,
                          hard_shoulder=None,
                          max_speed=None,
                          alt_route=None,
                          incident_management=None,
                          accident_risk_reduction=None,
                          modal_shift_trucks=None,
                          modal_shift_cars=None):
        """Compute travel time as F^-1(ppf) with interventions, Method 2."""
        q_distribution = True
        c, k, loc, scale = self.fit_burr(
            self.intervention_method_2(q_distribution,
                                       extra_lane,
                                       hard_shoulder,
                                       max_speed,
                                       alt_route,
                                       incident_management,
                                       accident_risk_reduction,
                                       modal_shift_trucks,
                                       modal_shift_cars))
        return stats.burr12.ppf(ppf, c, k, loc, scale)