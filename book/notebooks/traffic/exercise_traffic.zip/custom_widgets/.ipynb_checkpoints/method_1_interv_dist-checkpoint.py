from ipywidgets import interact
import ipywidgets as widgets
import matplotlib.pyplot as plt
from exercise_setup import Trajectory

t=Trajectory()
w_style = {'description_width': 'initial'}

interact(t.plot_distribution_method_1,
    extra_lane=widgets.Dropdown(options=[('None', None), ('1', 1), ('2', 2)],value=None,description='1: Extra Lanes'),
    max_speed=widgets.FloatSlider(min=1, max=170, step=10, value=130, description='3: Speed',style=w_style),
    alt_route=widgets.Dropdown(options=[('No alternate routes', None), ('1 alternate route', 1), ('2 alternate routes', 2)],value=None,description='4: Alt. Routes '),
    modal_shift_trucks=widgets.FloatSlider(min=0, max=20, step=4, value=0, description='7: Modal Shift, Trucks',style=w_style),
    modal_shift_cars=widgets.FloatSlider(min=0, max=20, step=4, value=0, description='8:  Modal Shift, Cars',style=w_style),
    baseline=widgets.Checkbox(value=True, description='Distribution, no interventions',indent=False),
    plot_type=widgets.ToggleButtons(options=[('PDF', 'pdf'), ('CDF', 'cdf'), ('1-CDF', 'exc')], description='Plot Type:'))
plt.show()