from ipywidgets import interact
import ipywidgets as widgets
import matplotlib.pyplot as plt
from exercise_setup import Trajectory

t=Trajectory()
w_style = {'description_width': 'initial'}

interact(t.plot_distribution_method_1_variables,
         t_0=widgets.FloatSlider(min=60*61.75/150, max=60*61.75/80,
                                 step=1, value=28.5),
         flowfactor=widgets.FloatSlider(min=0.2, max=t.C/5500,
                                        step=0.1, value=1.0),
         C=widgets.FloatSlider(min=4000, max=7000,
                               step=100, value=5600),
        baseline=widgets.Checkbox(value=True, description='Distribution, no interventions',indent=False))
plt.show()