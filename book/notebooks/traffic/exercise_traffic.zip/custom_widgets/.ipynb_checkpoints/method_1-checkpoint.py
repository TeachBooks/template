from ipywidgets import interact
import ipywidgets as widgets
import matplotlib.pyplot as plt
from exercise_setup import Trajectory

t=Trajectory()
w_style = {'description_width': 'initial'}

# Plotting estimated travel time vs flow for changing variables
interact(t.plot_method_1_sliders,
         t_0=widgets.FloatSlider(min=26,max=32,step=0.5,value=28.5),
         C=widgets.FloatSlider(min=4000,max=7000,step=100,value=5600))
plt.show()