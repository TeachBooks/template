from ipywidgets import interact
import ipywidgets as widgets
import matplotlib.pyplot as plt
from exercise_setup import Trajectory

t=Trajectory()
w_style = {'description_width': 'initial'}

interact(t.plot_distribution_method_2_variables,
         C=widgets.FloatSlider(min=4000,max=7000,step=100,value=5600),
         rCf=widgets.FloatSlider(min=0.1,max=0.6,step=0.1,value=0.2),
         t_cutoff=widgets.FloatSlider(min=20,max=45,step=2.5,value=32.5),
         baseline=widgets.Checkbox(value=True, description='Distribution, no interventions',indent=False))

plt.show()