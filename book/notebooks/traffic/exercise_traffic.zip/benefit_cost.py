import numpy as np
from scipy.stats import burr12
from exercise_setup import Trajectory
import warnings

warnings.filterwarnings('ignore')
t=Trajectory()

# Benefit function
rr = 0. #0.61
vot = 12.32

def benefit_method_1(q_distribution=True,
            extra_lane=None,
            max_speed=None,
            alt_route=None,
            modal_shift_trucks=None,
            modal_shift_cars=None):
    # Reference values
    t_no_interventions = t.intervention_method_1(q_distribution=True,
                                    max_speed=130.001,
                                    modal_shift_trucks=0.001,
                                    modal_shift_cars=0.001) 
    # c_ref, k_ref, loc_ref, scale_ref = t.fit_burr(t_no_interventions)
    # mean_ref, var_ref_dont_use, skew_ref, kurt_ref = burr12.stats(c_ref, k_ref, loc_ref, scale_ref, moments='mvsk')
    var_ref = t_no_interventions.var()
    mean_ref = t_no_interventions.mean()
    # Values after interventions
    # students can fill this out?
    t_with_interventions = t.intervention_method_1(q_distribution,
                                                   extra_lane,
                                                   max_speed,
                                                   alt_route,
                                                   modal_shift_trucks,
                                                   modal_shift_cars)
    # c, k, loc, scale = t.fit_burr(t_with_interventions)
    # mean, var_from_burr12, skew, kurt = burr12.stats(c, k, loc, scale, moments='mvsk')
    # print(f'Variance computed from parameterized distribution: {var_from_burr12:.2f}')
    var = t_with_interventions.var()
    mean = t_with_interventions.mean()
    # print(f'Variance computed directly from t with interventions: {var:.2f}')
        # Total benefit
    # return vot * (mean_ref + np.sqrt(var_ref) * rr) - vot * (mean + np.sqrt(var) * rr)
    return vot * (mean_ref - mean) + (np.sqrt(var_ref) - np.sqrt(var))* rr


# Cost:benefit function
def benefit_cost_method_1(q_distribution=True,
         extra_lane=None,
         max_speed=None,
         alt_route=None,
         modal_shift_trucks=None,
         modal_shift_cars=None):
    # Takes benefit from function they wrote
    B = benefit_method_1(q_distribution, extra_lane,
                         max_speed, alt_route, modal_shift_trucks,
                         modal_shift_cars)
    if B == 0:
        return 0
    # Initialize cost:
    C = 0
    
    # Cost of extra lane(s):
    if extra_lane == 1:
        C += 70
    elif extra_lane == 2:
        C += 100
    
    
    # Cost of increasing speed limit (per percentage):
    if max_speed != None:
        C += 700*(max_speed-130)/130
    
    # Cost of building alternative route(s):
    if alt_route == 1:
        C += 150
    elif alt_route ==2:
        C+= 180
    
    # Cost of modal shift (trucks):
    if modal_shift_trucks != None:
        C += 5*modal_shift_trucks
    
    # Cost of modal shift (cars):
    if modal_shift_cars != None:
        C += 8*modal_shift_cars
    print(f'The benefit-cost ratio using Method 1 is: {B/C:.3f}\n'
          f'Total cost for all interventions applied: {C:.3f} FCoins')
    return B/C

def benefit_method_2(q_distribution=False,
            extra_lane=None,
            hard_shoulder=None,
            max_speed=None,
            alt_route=None,
            incident_management=None,
            accident_risk_reduction=None,
            modal_shift_trucks=None,
            modal_shift_cars=None):
    # Reference values
    t_no_interventions = t.intervention_method_2(q_distribution=False,
                                     max_speed=130.001,
                                    incident_management=1,
                                    accident_risk_reduction=1,
                                    modal_shift_trucks=0.001,
                                    modal_shift_cars=0.001)
    # c_ref, k_ref, loc_ref, scale_ref = t.fit_burr(t_no_interventions)
    # mean_ref, var_ref_dont_use, skew_ref, kurt_ref = burr12.stats(c_ref, k_ref, loc_ref, scale_ref, moments='mvsk')
    var_ref = t_no_interventions.var()
    mean_ref = t_no_interventions.mean()
    # Values after interventions
    # students can fill this out?
    t_with_interventions = t.intervention_method_2(q_distribution,
                                                   extra_lane,
                                                   hard_shoulder,
                                                   max_speed,
                                                   alt_route,
                                                   incident_management,
                                                   accident_risk_reduction,
                                                   modal_shift_trucks,
                                                   modal_shift_cars)
    # c, k, loc, scale = t.fit_burr(t_with_interventions)
    # mean, var_from_burr12, skew, kurt = burr12.stats(c, k, loc, scale, moments='mvsk')
    # print(f'Variance computed from parameterized distribution: {var_from_burr12:.2f}')
    var = t_with_interventions.var()
    mean = t_with_interventions.mean()
    # print(f'Variance computed directly from t with interventions: {var:.2f}')
        # Total benefit
    # return vot * (mean_ref + np.sqrt(var_ref) * rr) - vot * (mean + np.sqrt(var) * rr)
    return vot * (mean_ref - mean) + (np.sqrt(var_ref) - np.sqrt(var))* rr



# Cost:benefit function
def benefit_cost_method_2(q_distribution=False,
         extra_lane=None,
         hard_shoulder=None,
         max_speed=None,
         alt_route=None,
         incident_management=None,
         accident_risk_reduction=None,
         modal_shift_trucks=None,
         modal_shift_cars=None):
    # Takes benefit from function they wrote
    B = benefit_method_2(q_distribution, extra_lane, hard_shoulder,
                         max_speed, alt_route, incident_management,
                         accident_risk_reduction, modal_shift_trucks,
                         modal_shift_cars)
    if B == 0:
        return 0
    # Initialize cost:
    C = 0
    
    # Cost of extra lane(s):
    if extra_lane == 1:
        C += 70
    elif extra_lane == 2:
        C += 100
    
    # Cost of constructing hard shoulders:
    if hard_shoulder == 1:
        C += 60
    
    # Cost of increasing speed limit (per percentage):
    if max_speed != None:
        C += 700*(max_speed-130)/130
    
    # Cost of building alternative route(s):
    if alt_route == 1:
        C += 150
    elif alt_route ==2:
        C+= 180
    
    # Cost of incident management:
    if incident_management != None:
        C += 2*incident_management
    
    # Cost of risk reduction:
    if accident_risk_reduction != None:
        C += 5*accident_risk_reduction
    
    # Cost of modal shift (trucks):
    if modal_shift_trucks != None:
        C += 5*modal_shift_trucks
    
    # Cost of modal shift (cars):
    if modal_shift_cars != None:
        C += 8*modal_shift_cars
    
    print(f'The benefit-cost ratio using Method 2 is: {B/C:.3f}\n'
          f'Total cost for all interventions applied: {C:.3f} FCoins')
    
    return B/C
